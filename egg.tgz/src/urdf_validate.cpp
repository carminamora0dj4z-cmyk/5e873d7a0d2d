// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Validate URDF tree\n", stdout);
  return lionss_run_workload("urdf_validate");
}
