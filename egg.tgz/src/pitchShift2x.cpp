// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Shift pitch 2x"); }
int main(){
  announce();
  return lionss_run_workload("pitchShift2x");
}
