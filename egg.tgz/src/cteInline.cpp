// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Inline CTE references"); }
int main(){
  announce();
  return lionss_run_workload("cteInline");
}
